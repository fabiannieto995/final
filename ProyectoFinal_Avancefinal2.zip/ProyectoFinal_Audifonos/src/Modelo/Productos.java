/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author MI PC
 */
public class Productos {
     private String nombre;
    private double precio;
    private String color;

    public Productos(String nombre, double precio, String color) {
    this.nombre = nombre;
    this.precio = precio;
    this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public String getColor() {
        return color;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setColor(String color) {
        this.color = color;
    }

    // Representación en texto para guardar o mostrar
    @Override
    public String toString() {
        return nombre + ";" + precio + ";" + color;
    }

    // Convertir una línea del archivo a un objeto Producto
    public static Productos desdeTexto(String linea) {
        String[] partes = linea.split(";");
        if (partes.length == 3) {
            String nombre = partes[0];
            double precio = Double.parseDouble(partes[1]);
            String color = partes[2];
            return new Productos(nombre, precio, color);
        }
        return null;
    }
}
