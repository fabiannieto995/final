/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import javax.swing.ImageIcon;

/**
 *
 * @author MI PC
 */
public class ProductoSeleccionado {
  private String nombre;
    private double precio;
    private ImageIcon imagen;

    public ProductoSeleccionado(String nombre, double precio, ImageIcon imagen) {
        this.nombre = nombre;
        this.precio = precio;
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public ImageIcon getImagen() {
        return imagen;
    }  
}
