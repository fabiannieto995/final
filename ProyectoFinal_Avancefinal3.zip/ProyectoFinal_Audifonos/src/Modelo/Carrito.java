/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MI PC
 */
public class Carrito {
   private static List<ProductoSeleccionado> productos = new ArrayList<>();

    public static void agregarProducto(ProductoSeleccionado producto) {
        productos.add(producto);
    }

    public static List<ProductoSeleccionado> obtenerProductos() {
        return productos;
    }

    public static double calcularTotal() {
        return productos.stream().mapToDouble(ProductoSeleccionado::getPrecio).sum();
    }

    public static void vaciarCarrito() {
        productos.clear();
    }  
}
