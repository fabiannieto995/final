/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author MI PC
 */
public class PilaUsuario {
    private NodoUsuario cima;

    public PilaUsuario() {
        this.cima = null;
    }

    public void apilar(Usuario usuario) {
        NodoUsuario nuevo = new NodoUsuario(usuario);
        nuevo.setSiguiente(cima);
        cima = nuevo;
    }

    public Usuario desapilar() {
        if (estaVacia()) {
            return null;
        }
        Usuario dato = cima.getDato();
        cima = cima.getSiguiente();
        return dato;
    }

    public boolean estaVacia() {
        return cima == null;
    }

    public Usuario verCima() {
        return estaVacia() ? null : cima.getDato();
    }

}
